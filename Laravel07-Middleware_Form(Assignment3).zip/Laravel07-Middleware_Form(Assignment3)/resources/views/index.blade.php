@extends('pages.master')

@section('title','Laravel Form')

@section('content')

   @yield('content')

@endsection